#ifndef _PID_FILE_H
#define _PID_FILE_H

int pid_file_create(char *pid_file);
int pid_file_delete(char *pid_file);

#endif
