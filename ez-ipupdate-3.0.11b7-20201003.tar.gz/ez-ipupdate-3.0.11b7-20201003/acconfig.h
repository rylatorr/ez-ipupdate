
#undef PACKAGE
#undef VERSION
#undef DEBUG
#undef HAVE_GETPASS
#undef HAVE_SYS_ERRLIST
#undef OS
#undef USE_MD5
#undef DEF_SERVICE
